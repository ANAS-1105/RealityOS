import { Link } from 'react-router-dom'
import { SignInWithFreebuff } from '@freebuff/auth/react'
import { AuthShell, AUTH_BUTTON, GoogleMark } from '@/components/layout/AuthShell'

/** Create an account — same single-action layout as sign-in. */
export default function SignUp() {
  return (
    <AuthShell
      title="Create your account"
      subtitle="One decision is all it takes to see the loop. You'll get a worked example first."
      footer={
        <>
          Already have an account?{' '}
          <Link to="/login" className="font-medium text-accent-300 underline-offset-2 hover:underline">
            Sign in
          </Link>
        </>
      }
    >
      <SignInWithFreebuff returnTo="/onboarding" className={AUTH_BUTTON}>
        <GoogleMark />
        Sign up with Google
      </SignInWithFreebuff>

      <p className="mt-3.5 text-center text-[0.78rem] leading-relaxed text-mist-500">
        Opens Freebuff&apos;s secure sign-in. Google, GitHub or Apple — no new password.
      </p>

      <ul className="mt-6 space-y-2.5 border-t border-ink-700/60 pt-5 text-[0.83rem] text-mist-400">
        <li>Three quick questions, then you&apos;re working.</li>
        <li>A demo simulation appears in your dashboard.</li>
        <li>Everything stays private to your account.</li>
      </ul>
    </AuthShell>
  )
}
