import { Timeline } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { Slider } from '@/components/ui/Form'
import { MetricValue } from '@/components/ui/Metric'

interface LiveWhatIfProps {
  base: {
    hoursPerDay: number
    success: number
    risk: number
    pressure: number
  }
  project: (hoursPerDay: number) => {
    success: number
    risk: number
    pressure: number
    coverage: number
    explanation: string
  }
}

export function LiveWhatIf({ base, project }: LiveWhatIfProps) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h3 className="text-[1.05rem] font-semibold text-mist-50">Try the What-If engine</h3>
          <p className="mt-1 text-[0.82rem] text-mist-400">Move focused hours per day and watch the same option recompute.</p>
        </div>
        <Badge tone="violet">Runs in your browser</Badge>
      </div>

      <div className="mt-5 space-y-5">
        <Slider
          label="Focused hours per day"
          value={base.hoursPerDay}
          min={0.5}
          max={12}
          step={0.5}
          onChange={(value) => void project(value)}
          format={(value) => `${value}h`}
          minLabel="0.5h"
          maxLabel="12h"
        />

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-ink-700/60 bg-ink-900/40 p-4">
            <p className="text-[0.68rem] uppercase tracking-[0.12em] text-mist-500">Completion</p>
            <p className="mt-2 text-3xl font-semibold num text-mist-50">
              <MetricValue value={base.success} />
            </p>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-700/70">
              <div className="h-full rounded-full bg-accent-500 transition-[width] duration-500" style={{ width: `${base.success}%` }} />
            </div>
            <p className="mt-1.5 text-[0.66rem] text-mist-500">higher is better</p>
          </div>

          <div className="rounded-xl border border-ink-700/60 bg-ink-900/40 p-4">
            <div className="flex items-center justify-between">
              <p className="text-[0.68rem] uppercase tracking-[0.12em] text-mist-500">Deadline risk</p>
              <Badge tone={base.risk > 55 ? 'high' : base.risk > 28 ? 'medium' : 'low'}>{base.risk}%</Badge>
            </div>
            <p className="mt-2 text-3xl font-semibold num text-mist-50">{base.risk}</p>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-700/70">
              <div className="h-full rounded-full bg-signal-high transition-[width] duration-500" style={{ width: `${base.risk}%` }} />
            </div>
            <p className="mt-1.5 text-[0.66rem] text-mist-500">lower is better</p>
          </div>

          <div className="rounded-xl border border-ink-700/60 bg-ink-900/40 p-4">
            <div className="flex items-center justify-between">
              <p className="text-[0.68rem] uppercase tracking-[0.12em] text-mist-500">Pressure</p>
              <span className="num text-mist-50">{base.pressure}/100</span>
            </div>
            <p className="mt-2 text-3xl font-semibold num text-mist-50">{base.pressure}</p>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-700/70">
              <div className="h-full rounded-full bg-violet-500 transition-[width] duration-500" style={{ width: `${base.pressure}%` }} />
            </div>
            <p className="mt-1.5 text-[0.66rem] text-mist-500">lower is better</p>
          </div>
        </div>

        <div className="rounded-xl border border-ink-700/60 bg-ink-900/40 p-4">
          <p className="flex items-center gap-2 text-[0.72rem] text-mist-500">
            <Timeline aria-hidden className="h-3.5 w-3.5" />
            <span className="uppercase tracking-[0.1em]">What changed</span>
          </p>
          <p className="mt-2 text-[0.82rem] leading-relaxed text-mist-300">Move the slider and this line updates with the trained model's explanation.</p>
        </div>
      </div>
    </Card>
  )
}
