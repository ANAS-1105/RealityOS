import { Link, useSearchParams } from 'react-router-dom'
import { SignInWithFreebuff } from '@freebuff/auth/react'
import { safeReturnTo } from '@freebuff/auth'
import { AuthShell, AUTH_BUTTON, GoogleMark } from '@/components/layout/AuthShell'

/**
 * Sign in.
 *
 * One action, one card. Identity is delegated to the Freebuff provider (OIDC +
 * PKCE), which presents Google, GitHub and Apple — RealityOS never sees a
 * password and never stores one.
 */
export default function Login() {
  const [params] = useSearchParams()
  const returnTo = safeReturnTo(params.get('returnTo')) || '/app/dashboard'

  return (
    <AuthShell
      title="Sign in"
      subtitle="Welcome back. Your simulations and recorded outcomes are exactly where you left them."
      footer={
        <>
          New to RealityOS?{' '}
          <Link to="/signup" className="font-medium text-accent-300 underline-offset-2 hover:underline">
            Create an account
          </Link>
        </>
      }
    >
      <SignInWithFreebuff returnTo={returnTo} className={AUTH_BUTTON}>
        <GoogleMark />
        Continue with Google
      </SignInWithFreebuff>

      <p className="mt-3.5 text-center text-[0.78rem] leading-relaxed text-mist-500">
        Opens Freebuff&apos;s secure sign-in. Google, GitHub or Apple — no new password.
      </p>

      <div className="mt-6 flex items-center gap-3">
        <span className="h-px flex-1 bg-ink-700/70" />
        <span className="text-[0.72rem] uppercase tracking-[0.14em] text-mist-500">secure</span>
        <span className="h-px flex-1 bg-ink-700/70" />
      </div>

      <p className="mt-4 text-center text-[0.8rem] text-mist-400">
        Sessions use secure, HTTP-only cookies. No password is ever stored here.
      </p>

      <p className="mt-4 text-center text-[0.78rem] text-mist-500">
        <Link to="/forgot-password" className="underline-offset-2 hover:underline">
          Can&apos;t get in?
        </Link>
      </p>
    </AuthShell>
  )
}
