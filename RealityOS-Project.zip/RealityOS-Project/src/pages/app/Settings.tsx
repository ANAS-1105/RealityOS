import { useState } from 'react'
import { Download, Moon, Sun, Trash2 } from 'lucide-react'
import { api } from '@/lib/api'
import { useSession } from '@/lib/session'
import { PageHeader } from '@/components/layout/PageHeader'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { ErrorState, InlineNote } from '@/components/ui/Feedback'
import { useToast } from '@/components/ui/Toast'

export default function Settings() {
  const { user, theme, setTheme } = useSession()
  const { push } = useToast()
  const [exporting, setExporting] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const exportData = async () => {
    setExporting(true)
    setError(null)
    try {
      const payload = await api.trainingExport()
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = url
      anchor.download = `realityos-training-${new Date().toISOString().slice(0, 10)}.json`
      anchor.click()
      URL.revokeObjectURL(url)
      push('success', 'Export downloaded.')
    } catch {
      setError('We could not export your data. Please try again.')
    } finally {
      setExporting(false)
    }
  }

  const deleteData = async () => {
    setDeleting(true)
    setError(null)
    try {
      await api.deleteAccount()
      push('success', 'Your account and all data have been deleted.')
    } catch {
      setError('We could not delete your data. Please try again.')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="space-y-10">
      <PageHeader eyebrow="Settings" title="Account" description="Who you are, how RealityOS looks, and what happens to your data." />

      {error ? <ErrorState message={error} onRetry={() => setError(null)} /> : null}

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="p-6">
          <h2 className="text-[0.9rem] font-medium text-mist-100">Signed in as</h2>
          <p className="mt-3 text-[0.95rem] text-mist-200">{user?.name ?? 'RealityOS user'}</p>
          <p className="mt-1 text-[0.85rem] text-mist-500">{user?.email ?? 'Freebuff account'}</p>
          <p className="mt-4 text-[0.78rem] text-mist-500">Your name comes from the identity provider.</p>
        </Card>

        <Card className="p-6">
          <h2 className="text-[0.9rem] font-medium text-mist-100">Appearance</h2>
          <p className="mt-2 text-[0.82rem] text-mist-400">Light is the default. System follows your OS.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button size="sm" variant={theme === 'light' ? 'primary' : 'ghost'} onClick={() => setTheme('light')} icon={<Sun aria-hidden className="h-4 w-4" />}>
              Light
            </Button>
            <Button size="sm" variant={theme === 'dark' ? 'primary' : 'ghost'} onClick={() => setTheme('dark')} icon={<Moon aria-hidden className="h-4 w-4" />}>
              Dark
            </Button>
            <Button size="sm" variant={theme === 'system' ? 'primary' : 'ghost'} onClick={() => setTheme('system')}>
              System
            </Button>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h2 className="text-[0.9rem] font-medium text-mist-100">Your data</h2>
        <p className="mt-2 text-[0.85rem] text-mist-400">Training rows are what calibrate the model for you.</p>

        <div className="mt-5 flex flex-wrap gap-3">
          <Button variant="secondary" onClick={exportData} loading={exporting} icon={<Download aria-hidden className="h-4 w-4" />}>
            Export training data
          </Button>
          <Button variant="danger" onClick={deleteData} loading={deleting} icon={<Trash2 aria-hidden className="h-4 w-4" />}>
            Delete all my data
          </Button>
        </div>

        <p className="mt-4 text-[0.78rem] leading-relaxed text-mist-500">
          Deletion removes your profile, every simulation, analysis and outcome, and every training row — immediately and irreversibly.
        </p>
      </Card>

      <InlineNote>
        <p className="text-[0.82rem] leading-relaxed text-mist-400">
          Sign-in is handled by Freebuff over OpenID Connect. RealityOS never stores your password, and no API key ever reaches the browser.
        </p>
      </InlineNote>
    </div>
  )
}
