import { Link } from 'react-router-dom'
import { AuthShell } from '@/components/layout/AuthShell'

/**
 * Account recovery.
 *
 * RealityOS holds no credentials, so there is no password to reset here. Rather
 * than show a form that does nothing, this page points to where recovery
 * actually happens.
 */
export default function ForgotPassword() {
  return (
    <AuthShell
      title="Can't get in?"
      subtitle="RealityOS never stores a password, so recovery happens with the identity provider."
      footer={
        <Link to="/login" className="font-medium text-accent-300 underline-offset-2 hover:underline">
          Back to sign in
        </Link>
      }
    >
      <ol className="space-y-5 text-[0.86rem] leading-relaxed text-mist-400">
        <li className="flex gap-3">
          <span className="num mt-0.5 shrink-0 text-accent-400">1</span>
          <span>
            Try signing in again — usually the session simply expired. Signing in restores it with no recovery step.
          </span>
        </li>
        <li className="flex gap-3">
          <span className="num mt-0.5 shrink-0 text-accent-400">2</span>
          <span>
            If you used Google, GitHub or Apple, recover through that provider — the credentials live with them.
          </span>
        </li>
        <li className="flex gap-3">
          <span className="num mt-0.5 shrink-0 text-accent-400">3</span>
          <span>
            Still locked out? Use Freebuff account recovery. A successful recovery restores the same RealityOS data.
          </span>
        </li>
      </ol>
    </AuthShell>
  )
}
